#pragma once
#ifndef ATLCOMCLI_H
#define ATLCOMCLI_H

#ifndef ATLASSERT
#define ATLASSERT(x)                                                           \
  {}
#endif

#ifndef ATLENSURE_RETURN
#define ATLENSURE_RETURN(expr)                                                 \
  do {                                                                         \
    int expr_assert = !!(expr);                                                \
    if (!(expr_assert))                                                        \
      return E_FAIL;                                                           \
  } while (0);
#endif

#include <atltrace.h>

#ifdef __cplusplus
#include <windows.h>

extern "C" HRESULT WINAPI AtlAdvise(IUnknown *pUnkCP, IUnknown *pUnk,
                                    const IID *iid, LPDWORD dpw);
extern "C" HRESULT WINAPI IUnknown_SetSite(IUnknown *punk, IUnknown *punkSite);

#include <comdef.h>

template <class T> class CAdapt {
public:
  CAdapt() {}

  CAdapt(const T &rSrc) { m_T = rSrc; }

  CAdapt(const CAdapt &rSrCA) { m_T = rSrCA.m_T; }

  CAdapt &operator=(const T &rSrc) {
    m_T = rSrc;
    return *this;
  }

  bool operator<(const T &rSrc) const { return m_T < rSrc; }

  bool operator==(const T &rSrc) const { return m_T == rSrc; }

  operator T &() { return m_T; }

  operator const T &() const { return m_T; }

  T m_T;
};

class CComBSTR {
public:
  CComBSTR();
  CComBSTR(const CComBSTR &);
  CComBSTR(REFGUID);
  CComBSTR(int);
  CComBSTR(int, LPCOLESTR);
  //  CComBSTR(int, LPCSTR);
  CComBSTR(LPCOLESTR);
  //  CComBSTR(LPCSTR);
  CComBSTR(CComBSTR &&);
  ~CComBSTR();

  HRESULT Append(const CComBSTR &);
  HRESULT Append(wchar_t);
  //  HRESULT Append(char);
  HRESULT Append(LPCOLESTR);
  //  HRESULT Append(LPCSTR);
  HRESULT Append(LPCOLESTR, int);
  HRESULT AppendBSTR(BSTR);
  HRESULT AppendBytes(const char *, int);
  HRESULT ArrayToBSTR(const SAFEARRAY *);
  HRESULT AssignBSTR(const BSTR);
  void Attach(BSTR);
  HRESULT BSTRToArray(LPSAFEARRAY *);
  unsigned int ByteLength() const;
  BSTR Copy() const;
  HRESULT CopyTo(BSTR *);
  HRESULT CopyTo(VARIANT *);
  BSTR Detach();
  void Empty();
  unsigned int Length() const;
  bool LoadString(HINSTANCE, UINT);
  bool LoadString(UINT);
  HRESULT ReadFromStream(IStream *);
  HRESULT ToLower();
  HRESULT ToUpper();
  HRESULT WriteToStream(IStream *);

  operator BSTR() const { return m_str; }
  bool operator!() const { return (m_str == NULL); }
  bool operator!=(CComBSTR &bstrSrc) const {
    return !(::VarBstrCmp(m_str, bstrSrc.m_str, LOCALE_USER_DEFAULT, 0) ==
             static_cast<HRESULT>(VARCMP_EQ));
  }
  bool operator!=(LPCOLESTR pszSrc) const {
    bool ret = 0;
    BSTR szSrc = ::SysAllocString(pszSrc);

    if (!szSrc) return 0;
    ret = ::VarBstrCmp(m_str, szSrc, LOCALE_USER_DEFAULT,
                        0) != static_cast<HRESULT>(VARCMP_EQ);
    ::SysFreeString(szSrc);
    return ret;
  }
  //  bool operator!=(LPCSTR) const;
  bool operator!=(int nNull) const { return (m_str != NULL); }
  BSTR *operator&() { return &m_str; }
  const CComBSTR &operator+=(const CComBSTR &bstrSrc) {
    AppendBSTR(bstrSrc.m_str);
    return *this;
  }
  const CComBSTR &operator+=(const LPCOLESTR pszSrc) {
    Append(pszSrc);
    return *this;
  }
  bool operator<(const CComBSTR &bstrSrc) const {
    return ::VarBstrCmp(m_str, bstrSrc.m_str, LOCALE_USER_DEFAULT, 0) ==
           static_cast<HRESULT>(VARCMP_LT);
  }
  bool operator<(const LPCOLESTR pszSrc) const {
    bool ret = 0;
    BSTR szSrc = ::SysAllocString(pszSrc);

    if (!szSrc) return 0;
    ret = ::VarBstrCmp(m_str, szSrc, LOCALE_USER_DEFAULT,
                        0) == static_cast<HRESULT>(VARCMP_LT);
    ::SysFreeString(szSrc);
    return ret;
  }
  //  bool operator<(const LPCSTR) const;
  const CComBSTR &operator=(const CComBSTR &bstrSrc) {
    AssignBSTR(bstrSrc.m_str);
    return *this;
  }
  const CComBSTR &operator=(LPCOLESTR pszSrc) {
    AssignBSTR((const BSTR)pszSrc);
    return *this;
  }
  //  CComBSTR& operator=(LPCSTR) const;
  bool operator==(const CComBSTR &bstrSrc) const {
    return ::VarBstrCmp(m_str, bstrSrc.m_str, LOCALE_USER_DEFAULT, 0) ==
           static_cast<HRESULT>(VARCMP_EQ);
  }
  bool operator==(LPCOLESTR pszSrc) const {
    bool ret = 0;
    BSTR szSrc = ::SysAllocString(pszSrc);

    if (!szSrc) return 0;
    ret = ::VarBstrCmp(m_str, szSrc, LOCALE_USER_DEFAULT,
                        0) == static_cast<HRESULT>(VARCMP_EQ);
    ::SysFreeString(szSrc);
    return ret;
  }
  //  bool operator==(LPCSTR) const;
  bool operator==(int nNull) const { return (m_str == NULL); }
  bool operator>(const CComBSTR &bstrSrc) const {
    return ::VarBstrCmp(m_str, bstrSrc.m_str, LOCALE_USER_DEFAULT, 0) ==
           static_cast<HRESULT>(VARCMP_GT);
  }

  bool operator>(LPCOLESTR pszSrc) const {
    bool ret = 0;
    BSTR szSrc = ::SysAllocString(pszSrc);

    if (!szSrc) return 0;
    ret = ::VarBstrCmp(m_str, szSrc, LOCALE_USER_DEFAULT,
                        0) == static_cast<HRESULT>(VARCMP_GT);
    ::SysFreeString(szSrc);
    return ret;
  }

  BSTR m_str;
};

inline CComBSTR::CComBSTR() { m_str = NULL; }

inline CComBSTR::CComBSTR(const CComBSTR &src) { m_str = src.Copy(); }

inline CComBSTR::CComBSTR(REFGUID guid) {
  OLECHAR szGUID[128];
  ::StringFromGUID2(guid, szGUID, 128);
  m_str = ::SysAllocString(szGUID);
}

inline CComBSTR::CComBSTR(int nSize) {
  if (nSize <= 0)
    m_str = NULL;
  else
    m_str = ::SysAllocStringLen(NULL, nSize);
}

inline CComBSTR::CComBSTR(int nSize, LPCOLESTR sz) {
  if (nSize <= 0)
    m_str = NULL;
  else
    m_str = ::SysAllocStringLen(sz, nSize);
}

inline CComBSTR::CComBSTR(LPCOLESTR pSrc) {
  if (pSrc == NULL)
    m_str = NULL;
  else
    m_str = ::SysAllocString(pSrc);
}

inline CComBSTR::CComBSTR(CComBSTR &&src) {
  m_str = src.m_str;
  src.m_str = NULL;
}

inline CComBSTR::~CComBSTR() {
  if (m_str)
    ::SysFreeString(m_str);
  m_str = NULL;
}

inline HRESULT CComBSTR::Append(const CComBSTR &bstrSrc) {
  return this->AppendBSTR(bstrSrc.m_str);
}

inline HRESULT CComBSTR::Append(wchar_t ch) { return this->Append(&ch, 1); }

inline HRESULT CComBSTR::Append(LPCOLESTR lpsz) {
  return Append(lpsz, static_cast<unsigned int>(wcslen(lpsz)));
}

inline HRESULT CComBSTR::Append(LPCOLESTR lpsz, int nLen) {
  const unsigned int n1 = ::SysStringLen(m_str);
  unsigned int n1Bytes = 0;
  unsigned int nSize = 0;
  unsigned int nSizeBytes = 0;

  nSize = n1 + nLen;
  nSizeBytes = nSize * sizeof(OLECHAR);
  n1Bytes = n1 * sizeof(OLECHAR);

  BSTR b = ::SysAllocStringLen(NULL, nSize);

  if (n1 > 0) {
    memcpy_s(b, nSizeBytes, m_str, n1Bytes);
  }
  memcpy_s(b + n1, nLen * sizeof(OLECHAR), lpsz, nLen * sizeof(OLECHAR));
  b[nSize] = '\0';
  ::SysFreeString(m_str);
  m_str = b;
  return S_OK;
}

inline HRESULT CComBSTR::AppendBSTR(BSTR p) {
  BSTR bstrTemp;

  VarBstrCat(m_str, p, &bstrTemp);
  ::SysFreeString(m_str);
  m_str = bstrTemp;
  return S_OK;
}

inline HRESULT CComBSTR::AssignBSTR(const BSTR bstrSrc) {
  if (m_str) {
    ::SysFreeString(m_str);
    m_str = NULL;
  }
  m_str = ::SysAllocString(bstrSrc);
  return S_OK;
}

inline void CComBSTR::Attach(BSTR src) {
  if (m_str) {
    ::SysFreeString(m_str);
    m_str = NULL;
  }
  m_str = src;
}

inline HRESULT CComBSTR::BSTRToArray(LPSAFEARRAY *ppArray) {
  return ::VectorFromBstr(m_str, ppArray);
}

inline unsigned int CComBSTR::ByteLength() const {
  if (m_str == NULL)
    return 0;
  else
    return ::SysStringByteLen(m_str);
}

inline BSTR CComBSTR::Copy() const {
  if (m_str == NULL)
    return NULL;
  else
    return ::SysAllocString(m_str);
}

inline HRESULT CComBSTR::CopyTo(BSTR *pbstr) {
  ::SysFreeString(*pbstr);
  if (m_str == NULL)
    *pbstr = NULL;
  else
    *pbstr = ::SysAllocString(m_str);
  return S_OK;
}

inline HRESULT CComBSTR::CopyTo(VARIANT *pvarDest) {
  ::VariantClear(pvarDest);
  if (m_str == NULL)
    pvarDest = NULL;
  else {
    V_BSTR(pvarDest) = ::SysAllocString(m_str);
    V_VT(pvarDest) = VT_BSTR;
  }
  return S_OK;
}

inline BSTR CComBSTR::Detach() {
  BSTR s = m_str;
  m_str = NULL;
  return s;
}

inline void CComBSTR::Empty() {
  if (m_str)
    ::SysFreeString(m_str);
  m_str = NULL;
}

inline unsigned int CComBSTR::Length() const { return ::SysStringLen(m_str); }

template <class T> class _NoAddRefReleaseOnCComPtr : public T {
private:
  STDMETHOD_(ULONG, AddRef)() = 0;
  STDMETHOD_(ULONG, Release)() = 0;
};

class CComVariant : public tagVARIANT {
public:
  CComVariant() {
    ::VariantInit(this);
  }
  CComVariant(const CComVariant &varSrc) {
    ::VariantInit(this);
    this->InternalCopy(&varSrc);
  }
  CComVariant(const VARIANT &varSrc) {
    ::VariantInit(this);
    this->InternalCopy(&varSrc);
  }
  CComVariant(LPCOLESTR lpszSrc) {
    ::VariantInit(this);
    *this = lpszSrc;
  }
  CComVariant(LPCSTR lpszSrc) {
    ::VariantInit(this);
    *this = lpszSrc;
  }
  CComVariant(bool bSrc) {
    V_VT(this) = VT_BOOL;
    if (bSrc)
      V_BOOL(this) = VARIANT_TRUE;
    else
      V_BOOL(this) = VARIANT_FALSE;
  }
  CComVariant(BYTE nSrc) {
    V_VT(this) = VT_UI1;
    V_UI1(this) = nSrc;
  }
  CComVariant(int nSrc, VARTYPE vtSrc = VT_I4) {
    V_VT(this) = vtSrc;
    if (vtSrc == VT_INT)
      V_INT(this) = nSrc;
    else
      V_I4(this) = nSrc;
  }
  CComVariant(unsigned int nSrc, VARTYPE vtSrc = VT_UI4) {
    V_VT(this) = vtSrc;
    if (vtSrc == VT_UINT)
      V_UINT(this) = nSrc;
    else
      V_UI4(this) = nSrc;
  }
  CComVariant(short nSrc) {
    V_VT(this) = VT_I2;
    V_I2(this) = nSrc;
  }
  CComVariant(unsigned short nSrc) {
    V_VT(this) = VT_UI2;
    V_UI2(this) = nSrc;
  }
  /*
    CComVariant(LONG nSrc, VARTYPE vtSrc = VT_I4) {
      V_VT(this) = vtSrc;
      if (vtSrc == VT_ERROR)
        V_ERROR(this) = nSrc;
      else
        V_I4(this) = nSrc;
    }
    CComVariant(ULONG nSrc) {
      V_VT(this) = VT_UI4;
      V_UI4(this) = nSrc;
    }
  */
  CComVariant(LONGLONG nSrc) {
    V_VT(this) = VT_I8;
    V_I8(this) = nSrc;
  }
  CComVariant(ULONGLONG nSrc) {
    V_VT(this) = VT_UI8;
    V_UI8(this) = nSrc;
  }
  CComVariant(float fltSrc) {
    V_VT(this) = VT_R4;
    V_R4(this) = fltSrc;
  }
  CComVariant(double dblSrc, VARTYPE vtSrc = VT_R8) {
    V_VT(this) = vtSrc;
    if (vtSrc == VT_DATE)
      V_DATE(this) = dblSrc;
    else
      V_R8(this) = dblSrc;
  }
  /*
    CComVariant(CY cySrc) {
      V_VT(this) = VT_CY;
      V_CY(this).hi = cySrc.hi;
      V_CY(this).lo = cySrc.lo;
    }
  */
  CComVariant(IDispatch *pSrc) {
    V_VT(this) = VT_DISPATCH;
    V_DISPATCH(this) = pSrc;
    if (V_DISPATCH(this) != NULL)
      V_DISPATCH(this)->AddRef();
  }
  CComVariant(IUnknown *pSrc) {
    V_VT(this) = VT_UNKNOWN;
    V_UNKNOWN(this) = pSrc;
    if (V_UNKNOWN(this) != NULL)
      V_UNKNOWN(this)->AddRef();
  }
  CComVariant(const SAFEARRAY *pSrc) {
    LPSAFEARRAY pSrcCopy;
    ::SafeArrayCopy(const_cast<LPSAFEARRAY>(pSrc), &pSrcCopy);
    ::SafeArrayGetVartype(const_cast<SAFEARRAY *>(pSrc), &V_VT(this));
    V_VT(this) |= VT_ARRAY;
    ::SafeArrayCopy(pSrcCopy, &V_ARRAY(this));
  }
  CComVariant(char cSrc) {
    V_VT(this) = VT_I1;
    V_I1(this) = cSrc;
  }
  CComVariant(const CComBSTR &bstrSrc) {
    V_VT(this) = VT_EMPTY;
    *this = bstrSrc.m_str;
  }
  ~CComVariant() { this->Clear(); }

  HRESULT Attach(VARIANT *pSrc) {
    ::VariantClear(this);
    memcpy_s(this, sizeof(CComVariant), pSrc, sizeof(VARIANT));
    V_VT(pSrc) = VT_EMPTY;
    return S_OK;
  }
  HRESULT ChangeType(VARTYPE vtNew, const VARIANT *pSrc = NULL) {
    if (pSrc == NULL)
      return ::VariantChangeType(this, this, 0, vtNew);
    else
      return ::VariantChangeType(this, const_cast<VARIANT *>(pSrc), 0, vtNew);
  }
  HRESULT Clear() { return ::VariantClear(this); }
  HRESULT Copy(const VARIANT *pSrc) {
    return ::VariantCopy(this, const_cast<VARIANT *>(pSrc));
  }
  HRESULT CopyTo(BSTR *pstrDest) {
    if (V_VT(this) != VT_BSTR)
      return E_FAIL;

    if (pstrDest)
      ::SysFreeString(*pstrDest);
    *pstrDest = ::SysAllocString(V_BSTR(this));
    return S_OK;
  }
  HRESULT Detach(VARIANT *pDest) {
    if (pDest) {
      ::VariantClear(pDest);
    }
    memcpy_s(pDest, sizeof(VARIANT), this, sizeof(CComVariant));
    V_VT(this) = VT_EMPTY;
    return S_OK;
  }
  ULONG GetSize() const {
    switch (V_VT(this)) {
    case VT_I1:
    case VT_UI1:
      return sizeof(BYTE);
    case VT_I2:
    case VT_UI2:
      return sizeof(SHORT);
    case VT_INT:
    case VT_UINT:
    case VT_I4:
    case VT_UI4:
      return sizeof(LONG);
    case VT_I8:
    case VT_UI8:
      return sizeof(LONGLONG);
    case VT_R4:
      return sizeof(float);
    case VT_R8:
      return sizeof(double);
    case VT_DATE:
      return sizeof(DATE);
    case VT_BOOL:
      return sizeof(VARIANT_BOOL);
    case VT_DISPATCH:
    case VT_UNKNOWN:
    case VT_BSTR:
      return sizeof(void *);
    case VT_CY:
      return sizeof(CY);
    case VT_ERROR:
      return sizeof(SCODE);
    }
    return 0;
  }
  HRESULT ReadFromStream(IStream *) { return E_NOTIMPL; }
  template <typename T> void SetByRef(T *) {}
  HRESULT WriteToStream(IStream *) { return E_NOTIMPL; }

  bool operator<(const VARIANT &varSrc) const {
    return ::VarCmp(const_cast<CComVariant*>(this),
                    const_cast<LPVARIANT>(&varSrc), 0, 0) ==
                    static_cast<HRESULT>(VARCMP_LT);
  }
  bool operator>(const VARIANT &varSrc) const {
    return ::VarCmp(const_cast<CComVariant*>(this),
                    const_cast<LPVARIANT>(&varSrc), 0, 0) ==
                    static_cast<HRESULT>(VARCMP_GT);
  }
  bool operator!=(const VARIANT &varSrc) const { return !operator==(varSrc); }
  bool operator==(const VARIANT &varSrc) const {
    if (V_VT(this) != V_VT(&varSrc))
      return false;
    else {
      return ::VarCmp(const_cast<CComVariant*>(this),
                      const_cast<LPVARIANT>(&varSrc), 0, 0) ==
                      static_cast<HRESULT>(VARCMP_EQ);
    }
  }
  CComVariant &operator=(const CComVariant &varSrc) {
    this->InternalCopy(&varSrc);
    return *this;
  }
  CComVariant &operator=(const VARIANT &varSrc) {
    this->InternalCopy(&varSrc);
    return *this;
  }
  CComVariant &operator=(LPCOLESTR lpszSrc) {
    ::VariantClear(this);
    V_BSTR(this) = ::SysAllocString(lpszSrc);
    V_VT(this) = VT_BSTR;
    return *this;
  }
  CComVariant &operator=(LPCSTR lpszSrc) { return *this; }
  CComVariant &operator=(bool bSrc) {
    V_VT(this) = VT_BOOL;
    if (bSrc)
      V_BOOL(this) = VARIANT_TRUE;
    else
      V_BOOL(this) = VARIANT_FALSE;
    return *this;
  }
  CComVariant &operator=(BYTE nSrc) {
    V_VT(this) = VT_UI1;
    V_UI1(this) = nSrc;
    return *this;
  }
  CComVariant &operator=(int nSrc) {
    V_VT(this) = VT_I4;
    V_I4(this) = nSrc;
    return *this;
  }
  CComVariant &operator=(unsigned int nSrc) {
    V_VT(this) = VT_UI4;
    V_UI4(this) = nSrc;
    return *this;
  }
  CComVariant &operator=(short nSrc) {
    V_VT(this) = VT_I2;
    V_I2(this) = nSrc;
    return *this;
  }
  CComVariant &operator=(unsigned short nSrc) {
    V_VT(this) = VT_UI2;
    V_UI2(this) = nSrc;
    return *this;
  }
  /*
    CComVariant& operator=(LONG nSrc) {
      V_VT(this) = VT_I4;
      V_I4(this) = nSrc;
      return *this;
    }
    CComVariant& operator=(ULONG nSrc) {
      V_VT(this) = VT_UI4;
      V_UI4(this) = nSrc;
      return *this;
    }
  */
  CComVariant &operator=(LONGLONG nSrc) {
    V_VT(this) = VT_I8;
    V_I8(this) = nSrc;
    return *this;
  }
  CComVariant &operator=(ULONGLONG nSrc) {
    V_VT(this) = VT_UI8;
    V_UI8(this) = nSrc;
    return *this;
  }
  CComVariant &operator=(float fltSrc) {
    V_VT(this) = VT_R4;
    V_R4(this) = fltSrc;
    return *this;
  }
  CComVariant &operator=(double dblSrc) {
    V_VT(this) = VT_R8;
    V_R8(this) = dblSrc;
    return *this;
  }
  /*
    CComVariant& operator=(CY cySrc) {
      V_VT(this) = VT_CY;
      V_CY(this).hi = cySrc.hi;
      V_CY(this).lo = cySrc.lo;
      return *this;
    }
  */
  CComVariant &operator=(IDispatch *pSrc) {
    V_VT(this) = VT_DISPATCH;
    V_DISPATCH(this) = pSrc;
    if (V_DISPATCH(this) != NULL) {
      V_DISPATCH(this)->AddRef();
    }
    return *this;
  }
  CComVariant &operator=(IUnknown *pSrc) {
    V_VT(this) = VT_UNKNOWN;
    V_UNKNOWN(this) = pSrc;
    if (V_UNKNOWN(this) != NULL) {
      V_UNKNOWN(this)->AddRef();
    }
    return *this;
  }
  CComVariant &operator=(const SAFEARRAY *pSrc) { return *this; }
  CComVariant &operator=(char cSrc) {
    V_VT(this) = VT_I1;
    V_I1(this) = cSrc;
    return *this;
  }

private:
  void InternalCopy(const VARIANT *pSrc) {
    HRESULT hr = this->Copy(pSrc);
    if (FAILED(hr)) {
      V_VT(this) = VT_ERROR;
      V_ERROR(this) = hr;
    }
  }
};

template <class T> class CComPtr;

template <class T> class CComPtrBase {
public:
  CComPtrBase() : p(NULL) {}
  CComPtrBase(T *lp) : p(lp) {
    if (p != NULL)
      p->AddRef();
  }
  void Swap(CComPtrBase &other) {
    T *pTemp = p;
    p = other.p;
    other.p = pTemp;
  }
  ~CComPtrBase() {
    if (p)
      p->Release();
  }

  HRESULT Advise(IUnknown *pUnk, const IID &iid, LPDWORD pdw) {
    /* in atl/atl.c */
    return AtlAdvise(p, pUnk, iid, pdw);
  }
  void Attach(T *p2) {
    if (p)
      p->Release();
    p = p2;
  }
  HRESULT CoCreateInstance(LPCOLESTR szProgID, LPUNKNOWN pUnkOuter = NULL,
                           DWORD dwClsContext = CLSCTX_ALL) {
    CLSID clsid;
    HRESULT hr = CLSIDFromProgID(szProgID, &clsid);
    if (SUCCEEDED(hr)) {
      hr = ::CoCreateInstance(clsid, pUnkOuter, dwClsContext, __uuidof(T),
                              (void **)&p);
    }
    return hr;
  }
  HRESULT CoCreateInstance(REFCLSID rclsid, LPUNKNOWN pUnkOuter = NULL,
                           DWORD dwClsContext = CLSCTX_ALL) {
    return ::CoCreateInstance(rclsid, pUnkOuter, dwClsContext, __uuidof(T),
                              (void **)&p);
  }
  HRESULT CopyTo(T **ppT) {
    if (ppT == NULL)
      return E_POINTER;
    *ppT = p;
    if (p) {
      p->AddRef();
    }
    return S_OK;
  }
  T *Detach() {
    T *pCopy;
    pCopy = p;
    p = NULL;
    return pCopy;
  }
  bool IsEqualObject(IUnknown *pOther) {
    if (p != NULL && pOther != NULL) {
      //_COM_SMARTPTR_TYPEDEF(IUnknown, IID_IUnknown);
      IUnknownPtr pUnk1;
      IUnknownPtr pUnk2;

      p->QueryInterface(IID_IUnknown, (void **)&pUnk1);
      pOther->QueryInterface(IID_IUnknown, (void **)&pUnk2);
      return (pUnk1 == pUnk2);
    } else if (p == NULL && pOther == NULL)
      return true;
    else
      return false;
  }
  template <class Q> HRESULT QueryInterface(Q **pp) const {
    return p->QueryInterface(__uuidof(Q), (void **)pp);
  }
  void Release() {
    T *pT = p;
    if (pT) {
      p = NULL;
      pT->Release();
    }
  }
  HRESULT SetSite(IUnknown *punkParent) {
    return IUnknown_SetSite(static_cast<IUnknown *>(p), punkParent);
  }

  operator T *() const { return p; }
  bool operator!() const {
    if (p)
      return false;
    return true;
  }
  T **operator&() { return &p; }
  T &operator*() const { return *p; }
  bool operator<(T *pT) const { return (p < pT); }
  bool operator==(T *pT) const { return (p == pT); }
  _NoAddRefReleaseOnCComPtr<T> *operator->() const {
    return (_NoAddRefReleaseOnCComPtr<T> *)p;
  }

  T *p;
};

template <class T> class CComPtr : public CComPtrBase<T> {
public:
  CComPtr() {}
  CComPtr(T *lp) : CComPtrBase<T>(lp) {}
  CComPtr(const CComPtr<T> &lp) : CComPtrBase<T>(lp.p) {}
  template <class Q> T *operator=(CComPtr<Q> &lp) {
    if (!IsEqualObject(lp)) {
      IUnknown **pp = (IUnknown **)&this->p;

      if (pp == NULL)
        return NULL;

      IUnknown *pTemp = *pp;

      if (lp == NULL || FAILED(lp->QueryInterface(__uuidof(T), (void **)pp)))
        *pp = NULL;

      if (pTemp)
        pTemp->Release();
      return *pp;
    }
    return *this;
  }
  T *operator=(T *lp) {
    CComPtr(lp).Swap(*this);
    return *this;
  }
  T *operator=(const CComPtr<T> &lp) {
    CComPtr(lp).Swap(*this);
    return *this;
  }
};

// template<class T, const IID* piid = &__uuidof(T)>
template <class T> class CComQIPtr : public CComPtr<T> {
public:
  CComQIPtr() : piid(&__uuidof(T)) {}
  CComQIPtr(T *lp) : piid(&__uuidof(T)), CComPtr<T>(lp) {}
  CComQIPtr(IUnknown *lp) : piid(&__uuidof(T)) {
    if (lp != NULL) {
      lp->QueryInterface(*piid, (void **)&this->p);
    }
  }
  CComQIPtr(const CComQIPtr<T> &lp) : CComPtr<T>(lp.p) {}

  T *operator=(T *lp) {
    CComPtr<T>(lp).Swap(*this);
    return *this;
  }
  T *operator=(IUnknown *lp) {
    // return static_cast<T*>(::AtlComQIPtrAssign((IUnknown**)&p, lp, *piid));
    IUnknown **pp = (IUnknown **)&this->p;

    if (pp == NULL)
      return NULL;

    IUnknown *pTemp = *pp;

    if (lp == NULL || FAILED(lp->QueryInterface(*piid, (void **)pp)))
      *pp = NULL;

    if (pTemp)
      pTemp->Release();
    return *pp;
  }
  T *operator=(const CComQIPtr<T> &lp) {
    CComPtr<T>(lp).Swap(*this);
    return *this;
  }
  const IID *piid;
};
#endif
#endif
