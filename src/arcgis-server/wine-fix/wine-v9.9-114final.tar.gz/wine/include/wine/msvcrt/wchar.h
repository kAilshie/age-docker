/*
 * Unicode definitions
 *
 * Derived from the mingw header written by Colin Peters.
 * Modified for Wine use by Jon Griffiths and Francois Gouget.
 * This file is in the public domain.
 */
#ifndef __WINE_WCHAR_H
#define __WINE_WCHAR_H

#include <corecrt_wctype.h>
#include <corecrt_wdirect.h>
#include <corecrt_wio.h>
#include <corecrt_wprocess.h>
#include <corecrt_wstdio.h>
#include <corecrt_wstdlib.h>
#include <corecrt_wstring.h>
#include <corecrt_wtime.h>
#include <sys/stat.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef WCHAR_MIN  /* also in stdint.h */
#define WCHAR_MIN 0U
#define WCHAR_MAX 0xffffU
#endif

#if _MSVCP_VER < 140 || (defined(_MSC_VER) && (_MSC_VER < 1900))
typedef int mbstate_t;
static inline int mbsinit(const mbstate_t *s)
{
    return !s || !*s;
}

static inline void mbs_zero(mbstate_t *s)
{
    *s = 0;
}

static inline void mbs_copy(mbstate_t *dst, const mbstate_t *src)
{
    if (src) *dst = *src;
        else mbs_zero(dst);
}

static inline void mbs_set(mbstate_t *s, int c)
{
    *s = c;
}

static inline int mbs_get(const mbstate_t *s)
{
    return *s;
}
#else
typedef struct _Mbstatet {
    __msvcrt_ulong  _Wchar;
    unsigned short  _Byte;
    unsigned short  _State;
} mbstate_t;
static inline int mbsinit(const mbstate_t *s)
{
    return !s || !s->_Wchar;
}

static inline void mbs_zero(mbstate_t *s)
{
    s->_Wchar = 0;
    s->_Byte  = 0;
    s->_State = 0;
}

static inline void mbs_copy(mbstate_t *dst, const mbstate_t *src)
{
    if(src) {
        dst->_Wchar = src->_Wchar;
        dst->_Byte  = src->_Byte;
        dst->_State = src->_State;
    } else mbs_zero(dst);
}

static inline void mbs_set(mbstate_t *s, int c)
{
    s->_Wchar = c;
}

static inline int mbs_get(const mbstate_t *s)
{
    return s->_Wchar;
}
#endif

#ifndef _WLOCALE_DEFINED
#define _WLOCALE_DEFINED
_ACRTIMP wchar_t* __cdecl _wsetlocale(int,const wchar_t*);
#endif /* _WLOCALE_DEFINED */

wchar_t __cdecl btowc(int);
size_t  __cdecl mbrlen(const char *,size_t,mbstate_t*);
size_t  __cdecl mbrtowc(wchar_t*,const char*,size_t,mbstate_t*);
size_t  __cdecl mbsrtowcs(wchar_t*,const char**,size_t,mbstate_t*);
size_t  __cdecl wcrtomb(char*,wchar_t,mbstate_t*);
int     __cdecl wcrtomb_s(size_t*,char*,size_t,wchar_t,mbstate_t*);
size_t  __cdecl wcsrtombs(char*,const wchar_t**,size_t,mbstate_t*);
int     __cdecl wctob(wint_t);

_ACRTIMP errno_t __cdecl wmemcpy_s(wchar_t *, size_t, const wchar_t *, size_t);

static inline wchar_t *wmemchr(const wchar_t *s, wchar_t c, size_t n)
{
    const wchar_t *end;
    for (end = s + n; s < end; s++)
        if (*s == c) return (wchar_t*)s;
    return NULL;
}

static inline int wmemcmp(const wchar_t *s1, const wchar_t *s2, size_t n)
{
    size_t i;
    for (i = 0; i < n; i++)
    {
        if (s1[i] > s2[i]) return 1;
        if (s1[i] < s2[i]) return -1;
    }
    return 0;
}

static inline wchar_t* __cdecl wmemcpy(wchar_t *dst, const wchar_t *src, size_t n)
{
    return (wchar_t*)memcpy(dst, src, n * sizeof(wchar_t));
}

static inline wchar_t* __cdecl wmemmove(wchar_t *dst, const wchar_t *src, size_t n)
{
    return (wchar_t*)memmove(dst, src, n * sizeof(wchar_t));
}

static inline wchar_t* __cdecl wmemset(wchar_t *s, wchar_t c, size_t n)
{
    size_t i;
    for (i = 0; i < n; i++)
        s[i] = c;
    return s;
}

#ifdef __cplusplus
}

extern "C++"
{

template <size_t size>
inline errno_t wcscpy_s(wchar_t (&dst)[size], const wchar_t *src)
{
    return ::wcscpy_s(dst, size, src);
}

}
#endif

#endif /* __WINE_WCHAR_H */
